<div class="language-select">
    <a href="{{ route('home.pages.index') }}">FA</a>
    |
    <a href="{{ route('home.pages.english') }}">EN</a>
</div>