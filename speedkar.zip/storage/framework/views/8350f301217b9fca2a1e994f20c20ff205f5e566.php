<?php $__env->startSection('content'); ?>
    <div class="row">

        <div class="col-xl-12 col-md-12 mb-4 p-md-5">

            <div class="mb-4">

                <h5 class="font-weight-bold">ویرایش دسته بندی</h5>

                <hr>

                <?php echo $__env->make('admin.sections.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <form action="<?php echo e(route('admin.categories.update', ['category' => $category->id])); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('put'); ?>

                    <div class="form-row content">

                        <div class="form-group col-md-3">

                            <label for="name">نام</label>
                            <input class="form-control" value="<?php echo e($category->name); ?>" type="text" name="name"
                                id="name">

                        </div>

                        <div class="form-group col-md-3">

                            <label for="name">نام انگلیسی</label>
                            <input class="form-control" value="<?php echo e($category->slug); ?>" type="text" name="slug"
                                id="slug">

                        </div>


                        <div class="form-group col-md-3">

                            <label for="is_active">وضعیت</label>
                            <select class="form-control" name="is_active" id="is_active">

                                <option value="1" <?php echo e($category->is_active ? 'selected' : ''); ?>>فعال</option>
                                <option value="0">غیرفعال</option>

                            </select>

                        </div>

                        <div class="form-group col-md-3">

                            <label for="name">توضیحات</label>
                            <input class="form-control" type="text" value="<?php echo e($category->description); ?>" name="description" id="description">

                        </div>

                    </div>

                    <center>
                        <button type="submit" class="btn btn-outline-primary mt-5">ویرایش</button>
                    </center>
                    <a href="<?php echo e(route('admin.categories.index')); ?>" class="btn mt-5 mr-3 btn-dark"> بازگشت </a>

                </form>


            </div>

        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\speedkar\resources\views/admin/categories/edit.blade.php ENDPATH**/ ?>