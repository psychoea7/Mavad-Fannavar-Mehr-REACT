<?php $__env->startSection('content'); ?>
    <div class="content">
        <!-- open sidebar menu -->
        <a class="btn btn-primary btn-customized open-menu" href="#" role="button">
            <i class="fas fa-bars"></i>
        </a>

        <?php echo $__env->make('home.sections.language', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="to-top rounded-top-btn">
            <a href="#" role="button">
                <i class="fas fa-chevron-circle-up"></i>
            </a>
          </div>

        <img class="img-fluid header-logo" src="<?php echo e(asset('images/logo-dark-1.png')); ?>" alt="">

        <div class="container my-4 py-5 expanded-product pt-5 pb-5">
            <div class="row pt-5">
                <div class="col-md-7 col-sm-12">
                    <h2><?php echo e($product->name); ?></h2>
                    <div class="divider-1 wow fadeInUp"><span class="w-100"></span></div>
                    <ul>
                        <?php $__currentLoopData = $product->attributes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($value->name); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                    <p><?php echo e($product->description); ?></p>

                </div>
                <div class="col-md-5 col-sm-12 h-100">
                    <div class="owl-carousel owl-theme .owl-dots .owl-dot text-center p-relative">
                        <div> <img  src="<?php echo e(asset(env('PRODUCT_IMAGE_PATH') . $product->primary_image)); ?>" alt="HTML5 Logo"/> </div>
                        <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div> <img  src="<?php echo e(asset(env('PRODUCT_IMAGE_PATH') . $image->image)); ?>" alt="HTML5 Logo"/> </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </div>


                </div>
            </div>
        </div>















        <?php echo $__env->make('home.sections.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('home.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\speedkar\resources\views/home/pages/products-expand.blade.php ENDPATH**/ ?>