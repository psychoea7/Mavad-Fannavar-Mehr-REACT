<div class="language-select">
    <a href="<?php echo e(route('home.pages.index')); ?>">FA</a>
    |
    <a href="<?php echo e(route('home.pages.english')); ?>">EN</a>
</div><?php /**PATH E:\speedkar\resources\views/home/sections/language.blade.php ENDPATH**/ ?>