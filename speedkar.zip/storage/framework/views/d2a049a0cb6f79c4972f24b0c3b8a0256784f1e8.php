<?php $__env->startSection('content'); ?>

<div class="row">

    <div class="col-xl-12 col-md-12 mb-4 p-md-5">

        <div class="d-flex justify-content-between mb-4">

            <h5 class="font-weight-bold">لیست درخواست ها (<?php echo e($collabs->total()); ?>)</h5>


        </div>

        <table class="table table-bordered table-striped text-center">

            <thead>

                <tr>

                    <th>
                        #
                    </th>
                    <th>
                        نام
                    </th>

                    <th>
                        تلفن
                    </th>

                    <th>
                        فایل
                    </th>

                </tr>

            </thead>

            <tbody>

                <?php $__currentLoopData = $collabs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $collab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <tr>
                    <th>
                    <?php echo e($collabs->firstItem() + $key); ?>

                    </th>

                    <th>
                        <?php echo e($collab->name); ?>

                    </th>

                    <th>
                        <?php echo e($collab->phone); ?>

                    </th>

                    <th>
                        <a href="<?php echo e(URL::to(env('Collab_FILE_PATH') . $collab->file)); ?>" class="btn btn-outline-success">دریافت فایل رزومه</a>
                    </th>


                    <th>
                        <a href="<?php echo e(route('admin.collabs.show' , ['collab' => $collab->id])); ?>" class="btn btn-outline-info">نمایش توضیحات</a>
                    </th>
                </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>

        </table>

    </div>
    <div><?php echo e($collabs->links()); ?></div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\speedkar\resources\views/admin/collabs/index.blade.php ENDPATH**/ ?>