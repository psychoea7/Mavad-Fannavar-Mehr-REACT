<?php $__env->startSection('content'); ?>
    <div class="row">

        <div class="col-xl-12 col-md-12 mb-4 p-md-5">

            <div class="mb-4">

                <h5 class="font-weight-bold">برند : <?php echo e($product->name); ?></h5>

                <hr>


                <div class="row">

                    <div class="form-group col-md-3">

                        <label for="name">نام</label>
                        <input class="form-control" type="text" value="<?php echo e($product->name); ?>" disabled>

                    </div>


                    <div class="form-group col-md-3">

                        <label for="name">وضعیت</label>
                        <input class="form-control" type="text" value="<?php echo e($product->is_active); ?>" disabled>

                    </div>

                    <div class="form-group col-md-3">

                        <label for="name">ویژگی های محصول</label>
                        <?php $__currentLoopData = $product->attributes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attribute): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <input class="form-control" type="text" value="<?php echo e($attribute->name); ?>" disabled>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>

                </div>
                <div class="form-group col-md-3">

                    <label for="name">تصویر اصلی محصول</label>

                    <img style="width: 200px;height: 100px;" src="<?php echo e(asset(env('PRODUCT_IMAGE_PATH') . $product->primary_image)); ?>" alt="">
                </div>

                <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="form-group col-md-3">
                <img style="width: 200px;height: 100px" src="<?php echo e(asset(env('PRODUCT_IMAGE_PATH') . $image->image)); ?>" alt="">
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <a href="<?php echo e(route('admin.products.index')); ?>" class="btn mt-5 mr-3 btn-dark"> بازگشت </a>



        </div>

    </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\speedkar\resources\views/admin/products/show.blade.php ENDPATH**/ ?>