<?php $__env->startSection('content'); ?>
    <div class="row">

        <div class="col-xl-12 col-md-12 mb-4 p-md-5">

            <div class="d-flex justify-content-between mb-4">

                <a class="btn btn-sm btn-outline-primary" href="<?php echo e(route('admin.blogs.create')); ?>">

                    <li class="fa fa-plus"></li>

                    ایجاد بلاگ

                </a>


            </div>

            <div class="form-row content">
                <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card form-group col-md-5">
                        <img class="card-img-top" src="<?php echo e(url(env('BLOG_IMAGE_PATH') . $blog->image)); ?>"
                            alt="Card image cap">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo e($blog->title); ?></h5>
                            <p class="card-text"><?php echo e($blog->text); ?></p>
                            <a href="<?php echo e(route('admin.blogs.show', ['blog' => $blog->id])); ?>"
                                class="btn btn-outline-info">نمایش بلاگ</a>
                            <div>

                                <a href="<?php echo e(route('admin.blogs.edit', ['blog' => $blog->id])); ?>"
                                    class="btn btn-outline-success">ویرایش بلاگ</a>

                            </div>

                            <div>
                                <form action="<?php echo e(route('admin.blogs.destroy', ['blog' => $blog->id])); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('delete'); ?>
                                    <button class="btn btn-outline-danger">حذف بلاگ</button>
                                </form>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\mavad_fanavare_mehr\blog\resources\views/admin/blog/index.blade.php ENDPATH**/ ?>