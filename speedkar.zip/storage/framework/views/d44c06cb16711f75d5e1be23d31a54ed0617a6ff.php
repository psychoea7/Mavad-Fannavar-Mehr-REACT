<?php $__env->startSection('content'); ?>
    <div class="content">
        <!-- open sidebar menu -->
        <a class="btn btn-primary btn-customized open-menu" href="#" role="button">
            <i class="fas fa-bars"></i>
        </a>

        <?php echo $__env->make('home.sections.language', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="to-top rounded-top-btn">
            <a href="#" role="button">
                <i class="fas fa-chevron-circle-up"></i>
            </a>
          </div>

        <img class="img-fluid header-logo" src="<?php echo e(asset('images/7.png')); ?>" alt="">





        <div class="container contact-us-wrapper pt-5 pb-5">
            <div class="row">
                <div class="col-md-12 mt-5">
                    <div class="section-6-form collab-form">
                        <form action="<?php echo e(route('collab')); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label class="sr-only" for="contact-email">نام و نام خانوادگی</label>
                                <input type="text" name="name" placeholder="نام و نام خانوادگی"
                                    class="contact-subject form-control" />

                                

                                <label class="sr-only" for="contact-email">شماره تماس</label>
                                <input type="text" name="phone" placeholder="شماره تماس"
                                    class="contact-subject form-control" />
                            </div>

                            <div class="form-group my-5">
                                <label class="sr-only" for="contact-email">ایمیل</label>
                                <input type="file" name="file" placeholder="ایمیل..."
                                    class="contact-email form-control" id="contact-email" />
                            </div>


                            <div class="form-group">
                                <label class="sr-only" for="contact-message">پیام</label>
                                <textarea name="message" placeholder="پیام..." class="contact-message form-control" id="contact-message"></textarea>
                            </div>
                            <button type="submit" class="btn btn-primary btn-customized">
                                ارسال رزومه <i class="fas fa-paper-plane"></i>
                            </button>
                        </form>
                    </div>
                </div>


            </div>


        </div>




        <?php echo $__env->make('home.sections.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('home.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\speedkar\resources\views/home/pages/collab.blade.php ENDPATH**/ ?>