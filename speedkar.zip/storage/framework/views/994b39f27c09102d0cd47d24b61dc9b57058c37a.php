<header class="bmd-layout-header ">
    <div class="navbar navbar-light d-flex justify-content-end bg-faded animate__animated animate__fadeInDown">
        
        
        <button id="toggleSide" class="navbar-toggler animate__animated animate__wobble animate__delay-2s" type="button"
            data-toggle="drawer" data-target="#dw-s1">
            <span class="navbar-toggler-icon"></span>
            <!-- <i class="material-Animation">menu</i> -->
        </button>
    </div>
</header>
<?php /**PATH E:\speedkar\resources\views/admin/sections/header.blade.php ENDPATH**/ ?>