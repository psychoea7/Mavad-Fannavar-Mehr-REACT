

<?php $__env->startSection('content'); ?>
    <div class="content">
        <!-- open sidebar menu -->
        <a class="btn btn-primary btn-customized open-menu" href="#" role="button">
            <i class="fas fa-bars"></i> 
        </a>

        <?php echo $__env->make('home.sections.language', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="to-top rounded-top-btn">
            <a href="#" role="button">
                <i class="fas fa-chevron-circle-up"></i>
            </a>
          </div>

        <img class="img-fluid header-logo" src="<?php echo e(asset('images/7.png')); ?>" alt="">

        <main>
            <div class="container py-5">
                <div class="row py-5">
                    <div class="col-md-12 weblog-post">
                        <div class="weblog-picture my-5">
                            <img class="img-fluid" src="<?php echo e(url(env('BLOG_IMAGE_PATH') . $blog->image)); ?>" alt="blog post image">

                        </div>
                        <div class="weblog-header mb-5">
                            <h3><?php echo e($blog->title); ?></h3>

                        </div>
                        <div class="weblog-date my-5">
                            <h5 class="text-secondary">
                               <?php echo e($blog->updated_at); ?></h5>

                        </div>

                        <div class="weblog-text my-5">
                            <p><?php echo $blog->text; ?></p>
                        </div>

                    </div>
                </div>
            </div>
        </main>




        <?php echo $__env->make('home.sections.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('home.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\speedkar\resources\views/home/pages/blog-post.blade.php ENDPATH**/ ?>