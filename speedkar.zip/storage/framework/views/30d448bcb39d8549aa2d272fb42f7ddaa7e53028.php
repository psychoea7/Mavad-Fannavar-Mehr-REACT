<?php $__env->startSection('content'); ?>

<div class="row">

    <div class="col-xl-12 col-md-12 mb-4 p-md-5">

        <div class="d-flex justify-content-between mb-4">

            <h5 class="font-weight-bold">لیست محصولات (<?php echo e($products->total()); ?>)</h5>

            <a class="btn btn-sm btn-outline-primary" href="<?php echo e(route('admin.products.create')); ?>">

                <li class="fa fa-plus"></li>

                ایجاد محصول

            </a>


        </div>

        <table class="table table-bordered table-striped text-center">

            <thead>

                <tr>

                    <th>
                        #
                    </th>
                    <th>
                        نام
                    </th>

                    <th>
                        وضعیت
                    </th>

                    <th>
                        عملیات
                    </th>

                </tr>

            </thead>

            <tbody>

                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <tr>
                    <th>
                    <?php echo e($products->firstItem() + $key); ?>

                    </th>

                    <th>
                        <?php echo e($product->name); ?>

                    </th>

                    <th>
                        <span class="<?php echo e($product->getRawOriginal('is_active') ? 'text-success' : 'text-danger'); ?>"><?php echo e($product->is_active); ?></span>
                    </th>

                    <th>
                        <a href="<?php echo e(route('admin.products.edit' , ['product' => $product->id])); ?>" class="btn btn-outline-info">ویرایش</a>
                        <a href="<?php echo e(route('admin.products.show' , ['product' => $product->id])); ?>" class="btn btn-outline-info">نمایش</a>
                    </th>
                </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>

        </table>

    </div>
    <div><?php echo e($products->links()); ?></div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\speedkar\resources\views/admin/products/index.blade.php ENDPATH**/ ?>