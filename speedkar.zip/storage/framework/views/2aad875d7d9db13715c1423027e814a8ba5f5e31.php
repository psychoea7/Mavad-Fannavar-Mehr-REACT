<?php $__env->startSection('content'); ?>

<form class="col-md-5 content" action="<?php echo e(route('admin.blogs.store')); ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div class="form-group">
      <label for="exampleFormControlInput1">عنوان</label>
      <input type="text" class="form-control" id="title" name="title" placeholder="عنوان">
    </div>
    <div class="form-group">
      <label for="image">انتخاب تصویر</label>
      <input class="form-control" type="file" id="image" name="image">
    </div>
    <div class="form-group">
      <label for="exampleFormControlTextarea1">متن بلاگ</label>
      <textarea class="form-control" id="exampleFormControlTextarea1" name="text" rows="3"></textarea>
    </div>
    <button type="submit" class="btn btn-success form-group">ثبت بلاگ</button>
  </form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\mavad_fanavare_mehr\blog\resources\views/admin/blog/create.blade.php ENDPATH**/ ?>