<?php $__env->startSection('content'); ?>

<div class="card content form-group col-md-5">
    <img class="card-img-top" src="<?php echo e(url(env('BLOG_IMAGE_PATH') . $blog->image)); ?>" alt="Card image cap">
    <div class="card-body">
        <h5 class="card-title"><?php echo e($blog->title); ?></h5>
        <p class="card-text"><?php echo e($blog->text); ?></p>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\mavad_fanavare_mehr\blog\resources\views/admin/blog/show.blade.php ENDPATH**/ ?>