<?php $__env->startSection('content'); ?>
    <div class="content">
        <!-- open sidebar menu -->
        <a class="btn btn-primary btn-customized open-menu" href="#" role="button">
            <i class="fas fa-bars"></i>
        </a>

        <?php echo $__env->make('home.sections.language', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="to-top rounded-top-btn">
            <a href="#" role="button">
                <i class="fas fa-chevron-circle-up"></i>
            </a>
          </div>

        <img class="img-fluid header-logo" src="<?php echo e(asset('images/7.png')); ?>" alt="">

        <!-- Section 5 -->
        <div class="section-5-container section-container pt-5 pb-5" id="blogPage">
            <div class="container pt-5">
                <div class="row">
                    <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-3 section-5-box wow fadeInUp">
                            <div class="section-5-box-image">
                                <img src="<?php echo e(url(env('BLOG_IMAGE_PATH') . $blog->image)); ?>" alt="portfolio-1" />
                            </div>
                            <h3>
                                <a href="<?php echo e(route('blogContent' , ['blog' => $blog->id])); ?>"><?php echo e($blog->title); ?></a>
                                <i class="fas fa-angle-left"></i>
                            </h3>
                            <div class="section-5-box-date">
                                <i class="far fa-calendar"></i><?php echo e($blog->updated_at); ?>

                            </div>
                            <p class="blog-text">
                                <?php echo e($blog->Stitle); ?>

                            </p>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

            </div>
        </div>






        <?php echo $__env->make('home.sections.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('home.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\speedkar\resources\views/home/pages/blog.blade.php ENDPATH**/ ?>