

<?php $__env->startSection('content'); ?>
    <div class="content">
        <!-- open sidebar menu -->
        <a class="btn btn-primary btn-customized open-menu" href="#" role="button">
            
            <i class="fas fa-bars"></i>
        </a>

        <?php echo $__env->make('home.sections.language', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="to-top rounded-top-btn">
            <a href="#" role="button">
                <i class="fas fa-chevron-circle-up"></i>
            </a>
        </div>


        <!-- Top content -->
        <div class="top-content section-container" id="top-content">
            <div class="container">
                <div class="row">
                    <div class="col col-md-10 offset-md-1 col-lg-8 offset-lg-2">
                        <h1 class="wow fadeIn page-header-logo">
                            <img class="img-fluid logo-text" src="<?php echo e(asset('images/7.png')); ?>" alt="">

                            
                        </h1>

                        
                    </div>
                </div>
            </div>
        </div>

        <!-- Section 1 -->
        <div class="section-1-container section-container services-icons" id="section-1">
            <div class="container">
                <div class="row">
                    <div class="col section-1 section-description wow fadeIn">
                        <h2 class="text-center">خدمات ما</h2>
                        <div class="divider-1 wow fadeInUp"><span></span></div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-3 section-1-box wow fadeInUp">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="section-1-box-icon">
                                    <a href="<?php echo e(route('home.pages.services')); ?>/#serviceFirst"><i
                                            class="fas fa-shopping-bag"></i></a>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <a href="<?php echo e(route('home.pages.services')); ?>/#serviceFirst" class="text-center">خدمات خرید و
                                    تامین کالا</a>

                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 section-1-box wow fadeInDown">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="section-1-box-icon">
                                    <a href="<?php echo e(route('home.pages.services')); ?>/#serviceSecond"><i
                                            class="fas fa-money-check-alt"></i></a>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <a href="<?php echo e(route('home.pages.services')); ?>/#serviceSecond" class="text-center">خدمات ارزی
                                    بازرگانی</a>

                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 section-1-box wow fadeInUp">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="section-1-box-icon">
                                    <a href="<?php echo e(route('home.pages.services')); ?>/#serviceThird"><i
                                            class="fas fa-shipping-fast"></i></a>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <a href="<?php echo e(route('home.pages.services')); ?>/#serviceThird" class="text-center">خدمات حمل بین
                                    المللی</a>

                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 section-1-box wow fadeInUp">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="section-1-box-icon">
                                    <a href="<?php echo e(route('home.pages.services')); ?>/#serviceFour"><i
                                            class="fas fa-truck-loading"></i></a>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <a href="<?php echo e(route('home.pages.services')); ?>/#serviceFour" class="text-center">خدمات
                                    گمرکی</a>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Section 2 -->
        <div class="section-2-container section-container section-container-gray-bg" id="section-2">
            <div class="container">
                <div class="row">
                    <div class="col section-2 section-description wow fadeIn"></div>
                </div>
                <div class="row">
                    <div class="col-md-8 col-sm-12 section-2-box wow fadeInLeft">
                        <h2>درباره ما</h2>
                        <div class="divider-1 wow fadeInUp mb-3"><span></span></div>
                        <p class="medium-paragraph">
                            شرکت بازرگانی اسپیدکار، با در اختیار داشتن گروه بازرگانی و مهندسی در زمینه تامین، واردات و عرضه
                            آلیاژ ها صنعتی با پشتوانه بیش از 10 سال تجربه فعالیت بازرگانی و خدمات مهندسی سطح، آماده ارایه
                            تجهیزات، مواد اولیه و آلیاژ های صنعتی تخصصی ضد سایش و ضد خوردگی در زمینه پوشش های حرارتی،
                            جوشکاری و پوشش دهی مورد نیاز صنایع کشور می باشد.
                            هدف این شرکت کمک به انتخاب علمی و دسترسی به آلیاژ های تخصصی و مهندسی مطابق با استاندارد های روز
                            دنیا در داخل کشور می باشد.
                        </p>
                        <p class="medium-paragraph">
                            شرکت بازرگانی اسپیدکار با نیازسنجی و شناسایی زمینه‌های مساعد و قابل اجرا جهت فعالیت در بخش‌ها و
                            حوزه‌های مختلف صنعتی و تولیدی ایران، قدم در عرصه صنعت فلزات و آلیاژ های نوین در این کشور گذاشته
                            و با بکارگیری نیروهایی جوان، متخصص و کارامد همراه با تجاربی مناسب در بسیاری از زمینه‌های اجرایی؛
                            تلاش دارد نقشی موثر و بسزا در بهبود، بروزرسانی و توسعه صنعت نوآور و به روز درکشور ایفا نماید.
                        </p>
                        <p class="medium-paragraph">واحد بازرگانی اسپیدکار با توجه به داشتن ارتباطات گستره با متخصصین رشته
                            متالورژی و مکانیک در خارج
                            از کشور و اخذ نمایندگی های فروش و خدمات پس از فروش از چندین برند مطرح اروپایی و آسیایی و همکاری
                            گسترده با تامین کنندگان معتبر خارجی در بخش مواد اولیه و ماشین الات صنعت پوشش دهی، امکان تأمین
                            طیف وسیعی از قطعات، تجهیزات و ماشین‌آلات مورد نیاز در پروژه‌های صنعتی شرکت‌ها و صنایع کشور و
                            ارائه خدمات پس از فروش مناسب آنها را در کوتاه‌ترین زمان ممکن و تحت استانداردهای بین‌المللی روز
                            دنیا را دارا می‌باشد.</p>

                    </div>
                    <div class="col-md-4 col-sm-12 section-2-box wow fadeInUp">
                        <img class="h-100" src="<?php echo e(asset('images/about-us.jpg')); ?>" alt="about-us" />
                    </div>
                </div>
            </div>
        </div>

        <!-- Section 3 -->
        <div class="section-3-container section-container" id="section-3">
            <div class="container">
                <div class="row">
                    <div class="col section-3 section-description wow fadeIn">
                        <h2 class="text-center">محصولات</h2>
                        <div class="divider-1 wow fadeInUp"><span></span></div>
                    </div>
                </div>

                <div class="row index-products wow fadeIn">
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div id="product<?php echo e($product->id); ?>"
                            onclick="location.href='<?php echo e(route('showProduct', ['product' => $product->id])); ?>'"
                            class="col-md-3 picture-item wow fadeInUp" data-groups='["<?php echo e($product->category_id); ?>"]'
                            data-date-created="2015-10-20" data-title="Central Park">
                            <div id="product" class="skill-card">
                                <header class="skill-card__header"><img class="skill-card__icon"
                                        src="<?php echo e(asset(env('PRODUCT_IMAGE_PATH') . $product->primary_image)); ?>"
                                        alt="HTML5 Logo" /></header>
                                <section class="skill-card__body">
                                    <h2 class="skill-card__title"><?php echo e($product->name); ?></h2><span
                                        class="skill-card__duration"><?php echo e($product->description); ?></span>
                                    <ul class="skill-card__knowledge">
                                        <?php $__currentLoopData = $product->attributes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><?php echo e($value->name); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <a href="<?php echo e(route('showProduct', ['product' => $product->id])); ?>">نمایش محصول</a>
                                    </ul>
                                </section>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>

                <div class="row">
                    <div class="col section-bottom-button wow fadeInUp">
                        <a class="btn btn-primary btn-customized-2" href="<?php echo e(route('product')); ?>" role="button">
                            مشاهده همه <i class="fas fa-sync"></i>
                        </a>
                    </div>
                </div>


            </div>
        </div>

        <!-- Section 4 -->
        <div class="section-4-container section-container section-container-image-bg" id="section-4">
            <div class="container">
                <div class="row">
                    <div class="col section-4 section-description wow fadeInLeftBig">
                        <h2>اسپیدکار؟</h2>
                        <p class="text-center">
                            اسپیدکار یا سپیدکار در متون فارسی شخصی را گویند که ظروف مس را سفید کند و او را قلعی گر و سفیدگر
                            نیز گویند.
                        </p>
                    </div>
                </div>
                <div class="row">
                    <div class="col section-bottom-button wow fadeInUp">
                        <a class="btn btn-primary btn-customized-2 " href="<?php echo e(route('home.pages.contact-us')); ?>" role="button">
                            تماس با ما <i class="fas fa-envelope"></i>
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <!-- Section 5 -->
        <div class="section-5-container section-container" id="section-5">
            <div class="container">
                <div class="row">
                    <div class="col section-5 section-description wow fadeIn">
                        <h2 class="text-center">وبلاگ</h2>
                        <div class="divider-1 wow fadeInUp"><span></span></div>

                    </div>
                </div>
                <div class="row">
                    <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-3 section-5-box wow fadeInUp"
                            onclick="location.href='<?php echo e(route('blogContent', ['blog' => $blog->id])); ?>'">
                            <div class="section-5-box-image">
                                <img src="<?php echo e(url(env('BLOG_IMAGE_PATH') . $blog->image)); ?>" alt="portfolio-1" />
                            </div>
                            <h3>
                                <a href="#"><?php echo e($blog->title); ?></a>
                                <i class="fas fa-angle-left"></i>
                            </h3>
                            <div class="section-5-box-date">
                                <i class="far fa-calendar"></i><?php echo e($blog->updated_at); ?>

                            </div>
                            <p class="blog-text">
                                <?php echo $blog->text; ?>

                            </p>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="row">
                    <div class="col section-bottom-button wow fadeInUp">
                        <a class="btn btn-primary btn-customized-2" href="<?php echo e(route('home.pages.blog')); ?>" role="button">
                            مشاهده همه <i class="fas fa-sync"></i>
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <!-- Section 6 -->
        

        <!-- Footer -->
        <?php echo $__env->make('home.sections.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('home.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\speedkar\resources\views/home/pages/index.blade.php ENDPATH**/ ?>