<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />


    <title> Speedkar Trading | Speedkar</title>
    <link href="https://unpkg.com/boxicons@2.1.1/css/boxicons.min.css" rel="stylesheet" />
    <!-- Bootstrap RTL ----------------------------------------------------->
    
    
    <link rel="shortcut icon" href="<?php echo e(asset('images/favicon.ico')); ?>" type="image/x-icon">
    <link rel="icon" href="<?php echo e(asset('images/favicon.ico')); ?>" type="image/x-icon">

    
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css"
        integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous" />
    <link rel="stylesheet" href="<?php echo e(asset('css/home.css')); ?>">

</head>

<body class="eng-page-body">
    <nav class="sidebar sidebar-eng">
        <!-- close sidebar menu -->
        <div class="dismiss">
            <i class="fas fa-arrow-left"></i>
        </div>

        <div class="logo">
            <h3>
                <a href="index.html">لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم</a>
            </h3>
        </div>

        <ul class="list-unstyled menu-elements">
            <li class="active">
                <a class="scroll-link" href="#top-content"><i class="fas fa-home"></i>Home</a>
            </li>
            <li>
                <a class="scroll-link" href="#section-1"><i class="fas fa-briefcase"></i>Trading Services</a>
            </li>
            <li>
                <a class="scroll-link" href="#section-2"><i class="fas fa-tags"></i>Products</a>
            </li>
            <li>
                <a class="scroll-link" href="#section-5"><i class="fas fa-pencil-alt"></i>Blog</a>
            </li>
            <li>
                <a class="scroll-link" href="#section-6"><i class="fas fa-envelope"></i>Contact Us</a>
            </li>
            <li>
                <a class="scroll-link" href="#section-6"><i class="fas fa-address-card"></i>About Us</a>
            </li>
            <li>
                <a class="scroll-link" href="#section-6"><i class="fas fa-user-friends"></i>Collaborate</a>
            </li>
            
        </ul>

        <div class="to-top">
            <a class="btn btn-primary btn-customized-3" href="#" role="button">
                <i class="fas fa-arrow-up"></i>To Top
            </a>
        </div>

        <div class="dark-light-buttons">
            <a class="btn btn-primary btn-customized-4 btn-customized-dark" href="#" role="button">Dark</a>
            <a class="btn btn-primary btn-customized-4 btn-customized-light" href="#" role="button">Light</a>
        </div>
    </nav>

    
    <!-- Wrapper -->
    <div class="content eng-content">
        <!-- open sidebar menu -->
        <a class="btn btn-primary btn-customized  open-menu" href="#" role="button">
            
            <i class="fas fa-bars text-dark"></i>
        </a>

        <?php echo $__env->make('home.sections.language', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="to-top rounded-top-btn">
            <a href="#" role="button">
                <i class="fas fa-chevron-circle-up"></i>
            </a>
        </div>

        

        <div class="top-content section-container" id="top-content">
            <div class="container">
                <div class="row">
                    <div class="col col-md-10 offset-md-1 col-lg-8 offset-lg-2">
                        <h1 class="wow fadeIn page-header-logo-2">
                            <img class="img-fluid logo-text" src="<?php echo e(asset('images/10.png')); ?>" alt="">

                            
                        </h1>

                        
                    </div>
                </div>
            </div>
        </div>

        <div class="container eng-container">
            <div class="row">
                <div class="col section-1 section-description wow fadeIn">
                    <h2 class="text-center">COMPANY OVERVIEW</h2>
                    <div class="divider-1 wow fadeInUp"><span></span></div>
                </div>

                <p><strong>Speedkar</strong>, established in Iran in 2015, is a Thermal Spray and hard facing and
                    cladding Technology specialist
                    in Iran including related technologies such as Laser Cladding, Hard Surfacing, Brazing, Additive
                    Manufacturing, Plasma Arc transfer (PTA).</p>
                <p>The products we offer are of state of the art technology and quality to ensure that any industry
                    application, be it aerospace, marine, research, oil and gas, Gas turbine, agricultural etc. is
                    consistently performed to the highest standards. With in-depth expertise and experience, we are also
                    well placed to assist you in selecting the most technologically advanced and cost-effective solution
                    to suit your needs. Underpinning all of these are our strong relationships with leading
                    manufacturers from the Germany, UK, Turkey, and China, etc.</p>
                <p><strong>Speedkar</strong> also prides itself with its reputation in after-sales service. With a team
                    of specialists with many years of experience, we provide competent and reliable technical support
                    and service.</p>
            </div>
        </div>
        <div class="container-fluid mt-5">
            <div class="row dark-row-eng">
                <div class="col-md-12 section-1 section-description wow fadeIn">
                    <h2 class="text-center">SERVICES AND TECHNICAL SUPPORT</h2>
                    <div class="divider-1 wow fadeInUp"><span></span></div>
                </div>
                <div class="col-md-8">
                    <p><strong>Speedkar</strong> has a team of technical specialists to offer a range of technical
                        support
                        and services. With our extensive experience and technical know-how, we are well placed to
                        provide
                        offer high service performance to address specific customer requirements:</p>
                    <ul class="p-0 text-left check-list-eng">
                        <li>System integration and turnkey installation</li>
                        <li>Preventive maintenance programs</li>
                        <li>System calibration services</li>
                        <li>Training for system operation</li>
                        <li>Training for spraying techniques</li>
                        <li>Material, coating and system consulting</li>
                    </ul>
                </div>

                <div class="col-md-4">
                    <img src="<?php echo e(asset('images/about-us.jpg')); ?>" alt="about-us" />
                </div>
            </div>
        </div>
        
        <div class="container eng-container">
            <div class="row">
                <div class="col section-1 section-description wow fadeIn">
                    <h2 class="text-center">PRODUCTS</h2>
                    <div class="divider-1 wow fadeInUp"><span></span></div>
                </div>

                <div class="col-md-12 mb-5">
                    <p>At <strong>Speedkar</strong>, we understand that it’s about having the best technology put into
                        the
                        right solution –
                        resulting in greater performance, improved product life, reduced costs, and risk mitigation.
                        With
                        our industry experience and technical knowledge, coupled with the latest technology from our
                        partners around the world, you can partner with us to build a solution for even the most
                        demanding
                        applications.</p>

                    <ul class="list-unstyled text-left">
                        <li><strong>1.</strong> Thermal Spray</li>
                        <li><strong>2.</strong> Hardfacig&Cladding</li>
                        <li><strong>3.</strong> LASER CLADDING & PTA</li>
                        <li><strong>4.</strong> Additive manufacturing</li>
                    </ul>
                </div>

                <div class="col-md-3 col-sm-12">
                    <div class="col eng-product-card-1">
                        <div class="eng-product-card-inner">
                            <a href="">FORTEBRAZE</a>
                            <p>Brazing Alloys & Fluxes</p>
                        </div>

                    </div>

                </div>

                <div class="col-md-3 col-sm-12">
                    <div class="col eng-product-card-2">
                        <div class="eng-product-card-inner">
                            <a href="">FORTEBRAZE</a>
                            <p>Brazing Foils & Pastes</p>
                        </div>
                    </div>
                </div>

                <div class="col-md-3 col-sm-12">
                    <div class="col eng-product-card-3">
                        <div class="eng-product-card-inner">
                            <a href="">FORTECOAT</a>
                            <p>Thermal Spray Powders</p>
                        </div>
                    </div>
                </div>

                <div class="col-md-3 col-sm-12">
                    <div class="col eng-product-card-4">
                        <div class="eng-product-card-inner">
                            <a href="">PURESPHERE</a>
                            <p>Powders For AM</p>
                        </div>
                    </div>
                </div>

            </div>

            <div class="row">

                <div class="col section-1 section-description wow fadeIn">
                    <h2 class="text-center">LASER CLADDING & PTA</h2>
                    <div class="divider-1 wow fadeInUp"><span></span></div>
                </div>

                <p><strong>Speedkar</strong> supplies Europe and Asian manufacture of materials. Laser Cladding ans PTA
                    systems have been successfully implemented laser clad coatings for a variety
                    of applications e.g. gas turbine rotor coatings, valve ball coatings, internal diameter coatings,
                    etc and mobile on-site laser clad repair coatings.</p>
            </div>

            

            <div class="row">

                <div class="col section-1 section-description wow fadeIn">
                    <h2 class="text-center">ADDITIVE MANUFACTURING POWDERS</h2>
                    <div class="divider-1 wow fadeInUp"><span></span></div>
                </div>

                <p>Additive manufacturing (AM) – otherwise commonly known as 3-D printing – has seen implementation in
                    the manufacturing of niche products and plastic prototypes for engineers and designers. However, it
                    has also now begun to be part of mass production of critical parts for a wider range of applications
                    in areas such as aerospace, automotive and medical. The benefits of AM include:</p>

                <ul class="list-unstyled text-left check-list-eng">
                    <li>Costs less to manufacturing a part with a complex design</li>
                    <li>Fewer design constraints</li>
                    <li>Changes of design are easy – simply by changing the CAD file</li>
                    <li>Prototypes can be manufactured and used immediately</li>
                    <li>Reduce wastage because only the material that is needed is used</li>
                </ul>
                <p><strong>Speedkar</strong> provides a range of quality gas-atomized, spherical metal additive
                    manufacturing powders
                    from Germany, USA , Turkey and China to suit your range of applications.</p>
            </div>

            

        </div>





        <footer class="footer-container mt-5">
            <div class="container">
                <div class="row">
                    <div class="col-md-3 col-sm-12">
                        <img class="img-fluid logo-text" src="<?php echo e(asset('images/12.png')); ?>"
                            alt="logo">
                    </div>

                    <div class="col-md-4 col-sm-12 mt-3">
                        <ul class="text-left">
                            <h4>Speedkar</h4>
                            <div class="divider-1 wow fadeInUp"><span></span></div>
                            <li><a href="">About Us</a></li>
                            <li><a href="">Contact Us</a></li>
                            <li><a href="">Collaborate</a></li>
                            <li><a href="">Blog</a></li>
                        </ul>

                    </div>

                    <div class="col-md-5 col-sm-12 mt-3">
                        <ul class="text-left">
                            <h4>Get In Touch</h4>
                            <div class="divider-1 wow fadeInUp"><span></span></div>
                            <li>Tehran, Fateh Highway, 11th Fateh Street, West 11th Golban, No 7</li>
                            <li><a href="tel:02166811664">02166811664</a></li>
                            <li><a href="mailto:info@speedkar.ir">speedkar@gmail.com</a></li>
                            <li>
                                <div class="section-6-social">
                                    <a href="#"><i class="fab fa-whatsapp"></i></a>
                                    <a href="#"><i class="fab fa-telegram"></i></a>
                                    <a href="#"><i class="fab fa-instagram"></i></a>
                                    <a href="#"><img class="aparat-icon"
                                            src="<?php echo e(asset('images/icons8-aparat-40.png')); ?>" alt=""></a>
                                </div>
                            </li>
                        </ul>

                    </div>


                </div>

                <div class="divider-1 w-100 wow fadeInUp"><span></span></div>
                <div class="row">
                    <div class="col-md-12 footer-copy-right">
                        <p><i class="far fa-copyright"></i> All rights belong to Speedkar Tejarat Newsad Company</p>
                        <p> Designed by <a href="https://beh-negaran.com"> Beh negaran</a></p>
                    </div>
                </div>
            </div>
        </footer>

    </div>
    <!-- Javascript -->
    <script src="<?php echo e(asset('js/home.js')); ?>"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/wow/0.1.12/wow.min.js"></script>
</body>

</html>
<?php /**PATH E:\speedkar\resources\views/home/pages/english.blade.php ENDPATH**/ ?>